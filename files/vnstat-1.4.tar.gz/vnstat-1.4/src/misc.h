void kerneltest(void);
int spacecheck(char *path);
